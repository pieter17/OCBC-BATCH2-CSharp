﻿namespace final_project.Configuration
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}