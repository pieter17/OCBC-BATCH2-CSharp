﻿using final_project.Configuration;

namespace final_project.Models.DTO.Responses
{
    public class RegistrationResponse:AuthResult
    {
        
    }
}