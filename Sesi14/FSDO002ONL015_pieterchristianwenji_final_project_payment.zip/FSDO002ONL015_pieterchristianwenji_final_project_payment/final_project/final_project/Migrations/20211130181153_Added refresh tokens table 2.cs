﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace final_project.Migrations
{
    public partial class Addedrefreshtokenstable2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
